<?php $this->load->view('pages/includes/header') ?>
<div class="container">
    <div class="card card-login mx-auto mt-5">
      <div class="card-header text-center"><img src="<?php echo base_url('assets/backend/img/logo.png?t='.mt_rand(0,9).'') ?>" /></div>
      <div class="card-header">Change Password</div>
      <div class="card-body">
		<?php echo $this->session->flashdata('msg'); ?>
        <form action="<?php echo base_url()?>register/forgetpassword" method="post">
          <div class="form-group">
            <label>Email address</label>
            <input class="form-control" type="text" name="email" placeholder="Enter email" required>
          </div>
          
          <button type="submit" class="btn btn-primary btn-block">Send</button>
        </form>
		<div class="text-center">
          <a class="d-block small mt-3" href="<?php echo base_url() ?>login">Login Page</a>       
        </div>
       </div>
    </div>
  </div>
<?php $this->load->view('pages/includes/footer') ?>
