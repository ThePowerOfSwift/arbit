<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="StartCheme">
  <title>XRPConnect - Platform</title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo base_url()?>assets/backend/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url()?>assets/backend/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Custom styles for this template-->
  <link href="<?php echo base_url()?>assets/backend/css/sb-admin.css" rel="stylesheet">
  <link href="<?php echo base_url()?>assets/backend/css/main.css" rel="stylesheet">
</head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="<?php echo base_url()?>assets/backend/js/main.js"></script>
  <script src="<?php echo base_url()?>assets/backend/vendor/jquery/jquery.validate.js"></script>
  <script src="<?php echo base_url()?>assets/backend/vendor/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url()?>assets/backend/vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url()?>assets/backend/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Core plugin JavaScript-->
  <script src="<?php echo base_url()?>assets/backend/vendor/jquery-easing/jquery.easing.min.js"></script>
<body class="bg-dark">
<div class="container">
    <div class="card card-register mx-auto mt-5">
      <div class="card-header text-center"><img src="<?php echo base_url('assets/backend/img/logo.png?t='.mt_rand(0,9).'') ?>" /></div>
      <div class="card-header">Register an Account</div>
      <div class="card-body">
        <form id="registerForm" action="<?php echo base_url()?>register/add_child_affiliate" method="post">
          <div class="form-group">
            <label>Email address</label>
            <input class="form-control" type="email" placeholder="Enter email" name="u_email" id="u_email" required>
          </div>
          <div class="form-group">
            <label>Username</label>
            <input type="text" class="form-control text-input" placeholder="Username" name="u_username" id="u_username" required>
          </div>
          <div class="form-group">
            <label>MEW/metamask wallet (Must enter wallet for airdrops, put N/A to skip)</label>
            <input type="text" class="form-control text-input" placeholder="Wallet" name="u_wallet">
          </div>          
          <div class="form-group">
            <label>Code affiliate</label>
            <input type="text" class="form-control text-input" placeholder="Blank if not exist" value="<?php echo $codeAff ?>" name="code_parent" readonly>
          </div>          
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputPassword1">Password</label>
                <input class="form-control" type="password" placeholder="Password" name="u_pwd" id="u_pwd" required>
              </div>
              <div class="col-md-6">
                <label for="exampleConfirmPassword">Confirm password</label>
                <input class="form-control" type="password" placeholder="Confirm password" id="pwd2">
              </div>
            </div>
            <p id="message"></p>
          </div>
          <button type="submit" class="btn btn-primary btn-block">Register</button>
        </form>
        <div class="text-center">
          <a class="d-block small mt-3" href="<?php echo base_url() ?>login">Login Page</a>
          <a class="d-block small" href="<?php echo base_url()?>forgot">Forgot Password</a>
        </div>
      </div>
    </div>
  </div>
<!-- Bootstrap core JavaScript-->
  
</body>

	


