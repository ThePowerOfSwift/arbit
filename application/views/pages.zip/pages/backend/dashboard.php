<div>
<div class="card mt-4">
            <div class="text-center">
                <h1 class="h2"><span>Crowdsale contract address :</span> <br/>TBD</h1>
            </div>
 </div>  
</div>

<div>
            <div class="text-center">
                <h5><span class="text-danger">Round 3 - $0.60 Starts 2-19-2018 4PM/GMT </span> <br/> </h5>
            </div>
        
</div>
   
 	 
<div>
            <div class="text-center">
                <img src="<?php echo base_url('assets/backend/img/qrcode.png') ?>" />
            </div>

            <div class="text-left">
                <h2 class="h3">Instructions :</h2><br>
                    <p>
                        <b>Step 1 :<b style="color: black;"> Join our telegram group for live support and live updates at t.me/xrpcofficial<br                        
                        <b style="color: black;">Step 2 :</b> Get <a href="https://www.myetherwallet.com/" target="_blank">MYETHERWALLET</a> or <a href="https://chrome.google.com/webstore/detail/metamask/nkbihfbeogaeaoehlefnkodbefgpgknn" target="_blank">MetaMask</a> <b style="color: red;">Never send from Exchange or online hot wallet </b><br>
                        <b>Step 3 :</b> Send ETH from one of those 2 wallets to the <b>crowdsale contract address</b>. (Due to ETH network congestion please set gas price at 5-10gwei & gas limit at 400 000)<br>
                        <b>Step 4 :</b> Smart contract will autodeliver XRPC tokens<br>
                        <b>Step 5 :</b> Watch tokens into your wallet:<br>
                        -Token contract address: 0xadb41fcd3df9ff681680203a074271d3b3dae526 <b style="color: red;">Warning : Don't send ETH to this address, this is not the crowdsale address</b><br>
                        -Symbol : XRPC <br>
                        -Decimal : 18<br>
                        <b>Step 6 :</b> Store XRPC in your wallet until platform is fully unlocked after Private Sale.<br>
                    </p>
            </div>

<b style="color: black;">
</div>
<div class="row">
    <div class="col-md-5">
        <div class="card mt-4">
            <div class="text-center">
                <p><span class="text-danger">Total supply</span> <br/>10,000,000 XRPC</p>
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="mt-4">
            <div class="text-center">
                <button class="btn btn-default btn-lg"><i class="fa fa-retweet"></i></button>
            </div>
        </div>
    </div>
    <div class="col-md-5">
        <div class="card mt-4">
            <div class="text-center">
                <p><span class="text-success">Crowdsale supply</span> <br/>9,650,000 XRPC</p>
            </div>
        </div>
    </div>
</div>
<br/>
*More infos about recommended Gwei : <a href="https://ethgasstation.info" target="_blank">https://ethgasstation.info</a></p>