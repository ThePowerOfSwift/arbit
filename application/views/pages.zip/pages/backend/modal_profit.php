<div class="modal fade" id="profitModal" tabindex="-1" role="dialog" aria-labelledby="profitModal" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
    <div class="modal-content">
        <div class="modal-body">
            <p class="text-center">
                <b>Lending profit calculator</b>
            </p>
        <div style="font-size:12px">
            <div class="row">
                <div class="col-md-6">
                    <label>Amount USD</label>
                    <input type="text" class="form-control">
                </div>
                <div class="col-md-6">
                    <label>Amount in XRPC</label>
                    <input type="text" class="form-control">
                </div>
            </div>
            <div class="col-md-12">
                <table class="table text-center" >
                    <thead>
                        <tr>
                        <th>Lending amount</th>
                        <th>Interest (Acrued daily)</th>
                        <th>Capital back</th>
                        </tr>
                    </thead>
                    <tbody>
                       <tr>
                            <td>$100 - $1,000</td>
                            <td>Daily variation rate</td>
                            <td>After 299 days</td>
                        </tr> 
						<tr>
                            <td>$1,001 - $5,000</td>
                            <td>Daily variation rate + 0.10%</td>
                            <td>After 239 days</td>
                        </tr> 
						<tr>
                            <td>$5,001 - $10,000</td>
                            <td>Daily variation rate + 0.20%</td>
                            <td>After 179 days</td>
                        </tr> 
						<tr>
                            <td>$10,001 - $25,000</td>
                            <td>Daily variation rate + 0.25%</td>
                            <td>After 119 days</td>
                        </tr> 
						<tr>
                            <td>+$25,001</td>
                            <td>Daily variation rate + 0.35%</td>
                            <td>After 89 days</td>
                        </tr> 
                    </tbody> 
                </table>
            </div>
            <div class="col-md-12" >
                <p class="text-danger">Optional capital lock boost</p>
                <table class="table text-center" >
                    <thead>
                        <tr>
                        <th></th>
                        <th>Locking period</th>
                        <th>Daily interest boost</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><input type="checkbox" name="checkbox_1"/></td>
                            <td>+ 30 days</td>
                            <td>+ 0.02%</td>
                        </tr> 
                        <tr>
                            <td><input type="checkbox" name="checkbox_2"/></td>
                            <td>+ 60 days</td>
                            <td>+ 0.05%</td>
                        </tr> 
						<tr>
                            <td><input type="checkbox" name="checkbox_3"/></td>
                            <td>+ 120 days</td>
                            <td>+ 0.10%</td>
                        </tr> 
                    </tbody> 
                </table>
            </div>
            <div class="col-md-12 border">
                <p>Your package</p>
                <table class="table text-center" >
                    <thead>
                        <tr>
                        <th>Amount</th>
                        <th>Bonus rate</th>
                        <th>	Capital release date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="text-danger">$0.00</td>
                            <td class="text-danger">0.00%</td>
                            <td class="text-danger">-</td>
                        </tr> 
                    </tbody> 
                </table>
                <p>Profit estimation based on average lending interest rate of</p>
                <p class="text-center">
                    <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-4">
                            <input type="radio" name="check_1"/><label>Last 7 days <span class="text-danger">(1.97%)</span></label>
                        </div>
                        <div class="col-md-4">
                            <input type="radio" name="check_1"/><label>Last 30 days <span class="text-danger">(1.84%)</span></label>
                        </div>
                        <div class="col-md-2"></div>
                    </div>
                </p>
                <table class="table text-center" >
                    <thead>
                        <tr>
                        <th>Daily</th>
                        <th>7 days</th>
                        <th>30 days</th>
                        <th>Release date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="text-danger">$0.00</td>
                            <td class="text-danger">$0.00</td>
                            <td class="text-danger">$0.00</td>
                            <td class="text-danger">$0.00</td>
                        </tr>
                    </tbody> 
                </table>
            </div>
            <br/>
            <div class="col-md-12 text-center" >
                <input type="checkbox" name="check_1"/>
                <label class="form-check-label">I read and understand the <a href="#" target="_blank">Terms and Conditions</a></label>
            </div>
        </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <button class="btn btn-primary">Submit</a>
        </div>
    </div>
    </div>
</div>