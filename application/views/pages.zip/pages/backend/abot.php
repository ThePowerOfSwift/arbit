<div class="row">
    <div class="col-md-5">
        <div class="card mt-4">
            <div class="text-center">
                <p><span class="text-danger">aBOT WALLET</span> <br/> $0.00</p>
            </div>
        </div>
    </div>
    <div class="col-md-2">
        <div class="mt-4">
            <div class="text-center">
                <button class="btn btn-default btn-lg"><i class="fa fa-forward"></i></button>
            </div>
        </div>
    </div>
    <div class="col-md-5">
        <div class="card mt-4">
            <div class="text-center">
                <p><span class="text-success">XRPC WALLET</span> <br/> $0.00</p>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12 text-center mt-4 mb-4">
        <p>Last 5 day's credited profit</p>
    </div>
</div>
<div class="row">
<?php 
$date1 = new DateTime('+1 day');
$date2 = new DateTime();
$date3= new DateTime('-1 day');
$date4 = new DateTime('-2 day');
$date5 = new DateTime('-3 day');
$date6 = new DateTime('-4 day');
$taux1= rand(0.40*10,1.90*10)/10;
$taux2= rand(0.40*10,1.90*10)/10;
$taux3= 1.50;
$taux4= 1.75;
$taux5= 1.80;
$taux6= 1.70;
?>


    <div class="col-md-2 border" align="center">
        <i class="fa fa-line-chart text-warning"></i>
        <span class="bold"><?php echo $taux1;?>%</span>
        <br/>
        <i class="fa fa-calendar text-info"></i>
        <span><?php echo $date1 -> format('Y-m-d');?> </span>
        <br/>
        <i class="fa fa-clock-o"></i>
        <span class="value">Pending</span>
    </div>
    <div class="col-md-2 border" align="center">
        <i class="fa fa-line-chart text-danger"></i>
        <span class="bold"><?php echo $taux2;?>%</span>
        <br/>
        <i class="fa fa-calendar text-info"></i>
        <span><?php echo $date2 -> format('Y-m-d');?></span>
        <br/>
        <i class="fa fa-clock-o"></i>
        <span class="value">Today</span>
    </div>
    <div class="col-md-2 border" align="center">
        <i class="fa fa-line-chart text-warning"></i>
        <span class="bold"><?php echo $taux3;?>%</span>
        <br/>
        <i class="fa fa-calendar text-info"></i>
        <span><?php echo $date3 -> format('Y-m-d');?></span>
        <br/>
        <i class="fa fa-clock-o"></i>
        <span class="value">Applied</span>
    </div>
    <div class="col-md-2 border" align="center">
        <i class="fa fa-line-chart text-danger"></i>
        <span class="bold"><?php echo $taux4;?>%</span>
        <br/>
        <i class="fa fa-calendar text-info"></i>
        <span><?php echo $date4 -> format('Y-m-d');?></span>
        <br/>
        <i class="fa fa-clock-o"></i>
        <span class="value">Applied</span>
    </div>
    <div class="col-md-2 border" align="center">
        <i class="fa fa-line-chart text-warning"></i>
        <span class="bold"><?php echo $taux5;?>%</span>
        <br/>
        <i class="fa fa-calendar text-info"></i>
        <span><?php echo $date5 -> format('Y-m-d');?></span>
        <br/>
        <i class="fa fa-clock-o"></i>
        <span class="value">Applied</span>
    </div>
    
    <div class="col-md-2 border" align="center">
        <i class="fa fa-line-chart text-danger"></i>
        <span class="bold"><?php echo $taux6;?>%</span>
        <br/>
        <i class="fa fa-calendar text-info"></i>
        <span><?php echo $date6 -> format('Y-m-d');?></span>
        <br/>
        <i class="fa fa-clock-o"></i>
        <span class="value">Applied</span>
    </div>
	
</div>
<div clas="row">
    <div class="col-md-12 mt-4 mb-4">
        <button class="btn btn-success" data-toggle="modal" data-target="#lendingModal">START aBOT ARBITRAGE</button>
        <button class="btn btn-default">REINVEST</button>
        <button class="btn btn-success"data-toggle="modal" data-target="#profitModal">PROFIT</button>
    </div>
</div>
<div class="row">
    <div class="col-md-3">
        <div class="card mt-4">
            <div class="text-center">
                <p><span class="text-info">Total aBOT investment</span> <br/> <span class="text-danger">$0.00</span></p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card mt-4">
            <div class="text-center">
                <p><span class="text-info">Active aBOT investment</span> <br/> <span class="text-danger">$0.00</span></p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card mt-4">
            <div class="text-center">
                <p><span class="text-info">Total capital released</span> <br/> <span class="text-danger">$0.00</span></p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card mt-4">
            <div class="text-center">
                <p><span class="text-info">Total profit earned</span> <br/> <span class="text-danger">$0.00</span></p>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12 mt-4">
            <h6>Your aBOT packages</h6>
        <div class="table-responsive">
            <table class="table" width="100%">
            <thead>
                <tr>
                <th>Arbitrage ID</th>
                <th>Amount</th>
                <th>Bonus</th>
                <th>Total Interests</th>
                <th>Start date</th>
                <th>Release date</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                <td></td>
                </tr>
            </table>
        </div>  
    </div>
</div>
<?php $this->load->view('pages/backend/modal_lending') ?>
<?php $this->load->view('pages/backend/modal_profit') ?>