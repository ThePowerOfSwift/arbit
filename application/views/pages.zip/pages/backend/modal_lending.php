<div class="modal fade" id="lendingModal" tabindex="-1" role="dialog" aria-labelledby="lendingModal" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
    <div class="modal-content" style="font-size:12px">
        <div class="modal-body">
            <p class="text-center">
                XRPC <span class="text-success"></span> <br/>
                Exchange rate: <span class="text-success">1 XRPC = $15</span>
            </p> 
            <div class="row">
                <div class="col-md-6">
                    <label>Amount FIAT *</label>
                    <input type="text" class="form-control">
                </div>
                <div class="col-md-6">
                    <label>Amount in XRPC</label>
                    <input type="text" class="form-control">
                </div>
            </div>
            <br/>
            <div class="col-md-12">
                <table class="table text-center" >
                    <thead>
                        <tr>
                        <th>aBOT investment amount</th>
                        <th>Profit (Acrued daily)</th>
                        <th>Investment Capital back</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>$250 - NO LIMIT</td>
                            <td>Daily profit rates vary</td>
                            <td>After 30 days</td>
                        </tr> 
                    </tbody> 
                </table>
            </div>
            <br/>
            <div class="col-md-12 border">
                <p class="text-success">Auto Reinvestment</p>
                <input type="checkbox" name="checkbox_1"/>
                <label class="form-check-label">Active</label>
                <p>By activating this function, money credited by this lending package will be reinvested automatically once it reach $250. Read more</p>
            </div>
            <br/>
            <div class="col-md-12 border" >
                <p class="text-danger">Optional profit lock boost</p>
                <table class="table text-center" >
                    <thead>
                        <tr>
                        <th></th>
                        <th>Locking period</th>
                        <th>Daily profit boost</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><input type="checkbox" name="checkbox_1"/></td>
                            <td>+ 30 days</td>
                            <td>+ 0.025%</td>
                        </tr> 
                        <tr>
                            <td><input type="checkbox" name="checkbox_2"/></td>
                            <td>+ 45 days</td>
                            <td>+ 0.05%</td>
                        </tr> 
						<tr>
                            <td><input type="checkbox" name="checkbox_3"/></td>
                            <td>+ 60 days</td>
                            <td>+ 0.75%</td>
                        </tr> 
                        <tr>
                            <td><input type="checkbox" name="checkbox_3"/></td>
                            <td>+ 90 days</td>
                            <td>+ 0.10%</td>
                        </tr> 
                    </tbody> 
                </table>
            </div>
            <br/>
            <div class="col-md-12 text-center" >
                <input type="checkbox" name="check_1"/>
                <label class="form-check-label">I read and understand the <a href="#" target="_blank">Terms and Conditions</a></label>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <button class="btn btn-primary">Submit</a>
        </div>
    </div>
    </div>
</div>