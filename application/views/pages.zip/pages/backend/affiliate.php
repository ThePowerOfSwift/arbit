<div class="card mt-4">
    <div class="card-header">
        <p class="text-center"> <p>Your affiliate commission XRPC will be airdropped after the ICO is over.</p> <p>If you use bots or fake users to sign up you will lose all of your XRPC commissions.</p> 
        <p>MAX COMMISSION FROM REFERRALS IS 100 XRPC</p>
        First 10,000 users will get 10 XRPC for signing up, will be airdropped to your registered MEW after ICO. (Enter your MEW in account tab after round 6)<br/>  <br/> <span class="text-danger"></span> </p>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table" width="100%">
              <thead>
                <tr>
                  <th>Only 1 level</th>
                  <th>Total affiliates</th>
                  <th></th>
                  <th>Total commission</th>
                </tr>
              </thead>
              <tbody>
			  <?php
				foreach ($affiliate as $a){
				  $chil_u_id = $a['child_u_id'];
				
			  ?>
				  <?php 
					foreach($all_user as $a){
					  if(empty($chil_u_id)){

					  }else{
						if($chil_u_id == $a['u_id']){
				  ?>
						<tr>
						  <td></td>
						  <td><?php echo $a['u_email'] ?></td>
						  <td></td>
						  <td>5 XRPC</td>
						</tr>
              <?php
							}
						} 
					} 
				} 
              ?>
            </table>
        </div>
    </div>
</div>