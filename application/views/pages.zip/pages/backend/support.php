<div class="card mt-4">
    <div class="card-header">
        <p class="text-center"> We're here to help <br/> Our support team is here to help you. Please send us a message using the form below. </p>
    </div>
    <div class="card-body">
        <form role="form" action="#" method="post"class="bv-form">
            <div class="form-group">
                <label>Title</label>
                <input type="text" class="form-control" name="title">
            </div>
            <div class="form-group">
                <label>Message</label>
                <textarea class="form-control" name="Contactmessage" style="height: 140px; resize: none;"></textarea>
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </form>
    </div>
</div>