<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title>XRPC</title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo base_url()?>assets/backend/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url()?>assets/backend/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="<?php echo base_url()?>assets/backend/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="<?php echo base_url()?>assets/backend/css/sb-admin.css?t=<?php echo time(); ?>" rel="stylesheet">
  <script src="https://www.amcharts.com/lib/3/amcharts.js"></script>
  <script src="https://www.amcharts.com/lib/3/serial.js"></script>
  <script src="https://www.amcharts.com/lib/3/amstock.js"></script>
  <script src="https://www.amcharts.com/lib/3/plugins/export/export.min.js"></script>
  <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css" media="all" />
  <script src="https://www.amcharts.com/lib/3/themes/light.js"></script>
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
    <!-- Navigation-->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
    <a class="navbar-brand" href="#"><img src="<?php echo base_url('assets/backend/img/logo-on-dark.png?t='.time().'') ?>" width="217.6" height="72" /></a> 
    
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span> 
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
       
        <li class="nav-item" data-toggle="tooltip" data-placement="right">
          <a class="nav-link" href="<?php echo base_url() ?>admin">
            <i class="fa fa-home"></i>
            <span class="nav-link-text">ICO</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right">
       <a class="nav-link">  <!-- href="<?php echo base_url() ?>admin/aBOT"> -->
            <i class="fa fa-line-chart"></i>
            <span class="nav-link-text">aBOT &nbsp;<i class="fa fa-lock" style="font-size:0.8em;"></i></span>
          </a>
        </li>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right">
       <a class="nav-link">  <!-- href="<?php echo base_url() ?>admin/mBOT"> -->
            <i class="fa fa-line-chart"></i>
            <span class="nav-link-text">mBOT &nbsp;<i class="fa fa-lock" style="font-size:0.8em;"></i></span>
          </a>
        </li>        
        <li class="nav-item" data-toggle="tooltip" data-placement="right">
		<a class="nav-link" href="<?php echo base_url() ?>admin/exchange">
            <i class="fa fa-money"></i>
            <span class="nav-link-text">Exchange</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right">
       <a class="nav-link">  <!-- href="<?php echo base_url() ?>admin/wallet"> -->
            <i class="fa fa-bank"></i>
            <span class="nav-link-text">Wallet &nbsp;<i class="fa fa-lock" style="font-size:0.8em;"></i></span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right">
		<a class="nav-link" href="<?php echo base_url() ?>admin/staking">
            <i class="fa fa-moon-o"></i>
            <span class="nav-link-text">Staking</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right">
		<a class="nav-link" href="<?php echo base_url() ?>admin/affiliate">
            <i class="fa fa-users"></i>
            <span class="nav-link-text">Affiliate</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right">
      <a class="nav-link" href="<?php echo base_url() ?>user">
            <i class="fa fa-cogs"></i>
            <span class="nav-link-text">Account</span>
          </a>
        </li>
        <li class="nav-item" data-toggle="tooltip" data-placement="right">
         <a class="nav-link">  <!-- href="<?php echo base_url() ?>admin/support"> -->
            <i class="fa fa-history"></i>
            <span class="nav-link-text">Support &nbsp;<i class="fa fa-lock" style="font-size:0.8em;"></i></span>
          </a>
        </li>
      </ul>
      <ul class="navbar-nav sidenav-toggler">
        <li class="nav-item">
          <a class="nav-link text-center" id="sidenavToggler">
            <i class="fa fa-fw fa-angle-left"></i>
          </a>
        </li>
      </ul>
      <div class="alert alert-info" align="center">
        <strong>During ICO stages </strong>some dashboard functionalities will be disabled.
      </div>
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link">
            <?php echo $this->session->userdata('u_username') ?> <br/>
            <?php echo $this->session->userdata('u_email') ?>
            <input type="hidden" value="<?php echo $this->session->userdata('u_id') ?>" name="u_id">
          </a>  
        </li>
        <li class="nav-item">
          <a class="nav-link" data-toggle="modal" data-target="#exampleModal">
            <i class="fa fa-fw fa-sign-out"></i></a>
        </li>
      </ul>
    </div>
  </nav>

<div class="content-wrapper">
    <div class="container-fluid">
        <?php echo $content; ?>
    </div>
</div>

    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright © <a href="https://xrpc.co" target="_blank">xrpc.co</a> 2018</small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="<?php echo base_url()?>logout">Logout</a>
          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url()?>assets/backend/vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url()?>assets/backend/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url()?>assets/backend/vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="<?php echo base_url()?>assets/backend/vendor/datatables/jquery.dataTables.js"></script>
    <script src="<?php echo base_url()?>assets/backend/vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="<?php echo base_url()?>assets/backend/js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="<?php echo base_url()?>assets/backend/js/sb-admin-datatables.min.js"></script>
  </div>
</body>

</html>