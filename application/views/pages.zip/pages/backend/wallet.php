<div class="card mt-4">
    <div class="card-body">       
			<iframe 
				 src="https://dimorinny.github.io/ethereum-erc20-wallet/"
				 width="100%" height="500">
				  <p>
					<a href="https://dimorinny.github.io/ethereum-erc20-wallet/">
					  Un lien à utiliser dans les cas où les navigateurs ne supportent
					  pas les <i>iframes</i>.
					</a>
				  </p>
			</iframe>
		</div>
	</div>
</div>