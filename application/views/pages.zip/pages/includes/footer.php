  <!-- Bootstrap core JavaScript-->
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="<?php echo base_url()?>assets/backend/js/main.js"></script>
  <script src="<?php echo base_url()?>assets/backend/vendor/jquery/jquery.validate.js"></script>
  <script src="<?php echo base_url()?>assets/backend/vendor/jquery/jquery.min.js"></script>
  <script src="<?php echo base_url()?>assets/backend/vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url()?>assets/backend/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- Core plugin JavaScript-->
  <script src="<?php echo base_url()?>assets/backend/vendor/jquery-easing/jquery.easing.min.js"></script>
</body>
<script src="https://my.hellobar.com/d5f2578905d428d7c75fb4bea54357b03b563ff1.js" type="text/javascript" charset="utf-8" async="async"></script>
	
<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = 'easvg61vlC';var d=document;var w=window;function l(){
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();</script>
<!-- {/literal} END JIVOSITE CODE -->
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-111271101-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-111271101-1');
</script>
</html>
